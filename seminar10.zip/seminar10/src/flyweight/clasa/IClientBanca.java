package flyweight.clasa;

public interface IClientBanca {
    void descriere(Cont cont);
}