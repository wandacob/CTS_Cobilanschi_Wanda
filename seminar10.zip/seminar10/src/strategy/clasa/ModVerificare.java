package strategy.clasa;

public interface ModVerificare {
    void verifica();
}